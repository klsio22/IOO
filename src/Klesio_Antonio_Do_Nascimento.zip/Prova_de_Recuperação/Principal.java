package Prova_de_Recuperação;

public class Principal {
    private Principal() {}

    public static void main(String[] args) {
        InterfaceTexto it = new InterfaceTexto();
        it.renderizar();
    } 
}
