package Prova_de_Recuperação;

import java.util.Calendar;


public abstract class Veiculo {

    private int numeroDeEixos;
    private String placa;

    public Veiculo(String placa, int numeroDeEixos) {
        this.placa = placa;
        this.numeroDeEixos = numeroDeEixos;
    }

    public String getPlaca() {
        return placa;
    }

    public int getNumeroDeEixos() {
        return numeroDeEixos;
    }

    public int getHora() {
        Calendar hora = Calendar.getInstance();
        return hora.get(Calendar.HOUR_OF_DAY);
    }

    public int getMinuto(){
        Calendar minuto = Calendar.getInstance();
        return minuto.get(Calendar.MINUTE);
    }

    public int getSegundo(){
        Calendar segundo = Calendar.getInstance();
        return segundo.get(Calendar.SECOND);
    }

    public int getDia(){
        Calendar dia = Calendar.getInstance();
        return dia.get(Calendar.DATE);
    }

    public int getAno(){
        Calendar ano = Calendar.getInstance();
        return ano.get(Calendar.YEAR);
    }

    public int getMes(){
        Calendar Mes = Calendar.getInstance();
        return Mes.get(Calendar.MONTH);
    }

    public abstract double getTarifa();

    public abstract String getTipo();

    public abstract String getTipoDeTarifa();


}
