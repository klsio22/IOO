package AA3_IOO_3;
//Klésio Antônio do Nascimento

public class Principal {

	private Principal() {}

	public static void main(String[] args) {
		InterfaceTexto i = new InterfaceTexto();
		i.renderizar();
	}
}