package AA4_IOO_4;
//Klésio Antônio do Nascimento - Turma: SI1B

public class Principal {
    private Principal() {}

    public static void main(String[] args) {
        InterfaceTexto it = new InterfaceTexto();
        it.renderizar();
    } 
}
